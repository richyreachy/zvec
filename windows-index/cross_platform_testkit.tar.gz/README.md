# zvec cross-platform index compatibility test kit (Cohere 10k)

Built on Windows with zvec **v0.7.0** (tag `v0.7.0`, commit 8321c13) from
`C:\bench\cohere\zvec-cross-platform\`. The goal: verify that index files built
on Windows open and query identically on Linux / macOS with the same zvec tag.

## Contents

| Path | Description |
|---|---|
| `cohere_train_vector_10k.zvec.vecs` | base data: 10,000 x 768 fp32 (zvec .vecs format) |
| `cohere_test_vector_1m.1000.new.txt` | 1000 test queries (`<id>;<floats>;`) |
| `neighbors_10k.txt` | ground truth: top-100 ids per query (`<qid>;<id> <id> ...`) |
| `build_cross_platform_indexes.py` | index build script (rebuild from scratch if needed) |
| `verify_cross_platform.py` | verify + baseline save/compare script |
| `baselines/<type>.json` | Windows result baselines (recall + per-query ids/scores) |
| `index_flat_sparse_10k/` | dense FP32 FLAT (COSINE) + sparse FP32 FLAT (IP) |
| `index_hnsw_sparse_10k/` | dense FP32 HNSW (COSINE, INT8, m=50, efC=500) + sparse FP32 HNSW (IP, m=16, efC=200) |
| `index_ivf_10k/` | dense FP32 IVF (COSINE, nlist=100, n_iters=10) |
| `index_vamana_10k/` | dense FP32 VAMANA (COSINE, R=64, L=100, alpha=1.2) |

Sparse vectors are synthesized deterministically from the doc key by a pure
integer hash (`make_sparse_vector` in the build script): 64 nonzeros over a
32768-dim vocabulary. The same generator runs on the query side, so sparse
results are fully reproducible on every platform.

## Windows build results (baseline, zvec 0.7.0, python 3.12)

| Index | recall@1 | recall@10 | recall@100 | QPS (1 thread) | Query params |
|---|---|---|---|---|---|
| flat_sparse | 1.0000 | 1.0000 | 1.0000 | 632 | brute force |
| hnsw_sparse | 0.9660 | 0.9637 | 0.9737 | 1134 | ef=500 (sparse_ef=200) |
| ivf | 1.0000 | 1.0000 | 1.0000 | 642 | nprobe=100 (exhaustive; nprobe=10 -> recall@1 0.9920) |
| vamana | 1.0000 | 1.0000 | 0.9998 | 638 | ef_search=500 |

## How to validate on another platform (Linux / macOS)

1. Build the wheel from the same tag:

   ```bash
   git checkout v0.7.0
   git submodule update --init --checkout
   # python -m build --wheel  (see zvec repo docs; needs CMake >= 3.26)
   pip install --force-reinstall dist/zvec-0.7.0-*.whl
   ```

2. Copy and extract this kit. **Use tar, not zip** — the collections contain
   an empty `idmap.0/1/` directory that zip drops:

   ```bash
   tar xzf index_<type>_10k.tar.gz
   ```

3. Run verification with baseline comparison (defaults match the baseline
   params above):

   ```bash
   python verify_cross_platform.py --index index_flat_sparse_10k  --type flat_sparse  --compare-baseline baselines/flat_sparse.json
   python verify_cross_platform.py --index index_hnsw_sparse_10k  --type hnsw_sparse  --compare-baseline baselines/hnsw_sparse.json
   python verify_cross_platform.py --index index_ivf_10k          --type ivf          --compare-baseline baselines/ivf.json
   python verify_cross_platform.py --index index_vamana_10k       --type vamana       --compare-baseline baselines/vamana.json
   ```

4. Interpretation:
   - `[compare] OK` — index files are cross-platform compatible: recall
     matches and the first 100 dense queries (+20 sparse sanity queries on
     flat_sparse/hnsw_sparse) return identical id sequences with scores equal
     to within 1e-6.
   - `[compare] FAILED` with details — divergence; compare the reported
     recall / id-sequence / score diffs per index type to localize it.

   Note: the graph indexes (hnsw_sparse, vamana) are approximate; identical
   id sequences are expected only for the recorded queries when the search is
   deterministic. `flat_sparse`/`ivf(nprobe=100)`/`vamana` at these settings
   are exact and must match bit-for-bit in ids.

5. (Optional) Rebuild the indexes on the target platform with
   `build_cross_platform_indexes.py` and compare the two platforms' fresh
   baselines to test build reproducibility as well:

   ```bash
   python build_cross_platform_indexes.py
   python verify_cross_platform.py --index index_hnsw_sparse_10k --type hnsw_sparse --save-baseline baselines_local/hnsw_sparse.json
   ```

## Notes

- Doc ids are the uint64 keys from the .vecs file (a shuffled permutation of
  0..9999), stored as strings.
- Each collection is a self-contained zvec collection directory: open with
  `zvec.open(path, CollectionOption(read_only=True, enable_mmap=True))`.
- Dense field name: `emb` (768-dim); sparse field name: `sparse_emb`.
- Index schema/version info is in each collection's `manifest.*` (protobuf,
  relative paths only — relocatable).
