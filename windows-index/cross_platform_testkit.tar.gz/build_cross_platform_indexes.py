"""Build cross-platform zvec test indexes over the Cohere 10k sample.

Four index types are built, each into its own directory under --out-root:

  flat_sparse  dense FP32 FLAT (COSINE)        + sparse FP32 FLAT (IP)
  hnsw_sparse  dense FP32 HNSW (COSINE, INT8)  + sparse FP32 HNSW (IP)
  ivf          dense FP32 IVF (COSINE, kmeans)
  vamana       dense FP32 VAMANA graph (COSINE)

The source .vecs file has an empty sparse section, so sparse vectors are
synthesized with a pure-integer hash (fully deterministic on every platform
and Python version: no reliance on random module internals).

The resulting collection directories are self-contained zvec collections:
copy them to macOS/Linux and open with zvec.open() built from the same tag.

Usage:
    python build_cross_platform_indexes.py
    python build_cross_platform_indexes.py --types ivf,vamana
    python build_cross_platform_indexes.py --limit 200 --out-root smoke_dir
"""
from __future__ import annotations

import argparse
import struct
import time
from pathlib import Path

import numpy as np

import zvec
from zvec import (
    CollectionOption,
    CollectionSchema,
    Doc,
    FlatIndexParam,
    HnswIndexParam,
    IVFIndexParam,
    OptimizeOption,
    VectorSchema,
    VamanaIndexParam,
)
from zvec.typing import DataType, MetricType, QuantizeType

HEADER_SIZE = 104
UINT64_MAX = 0xFFFFFFFFFFFFFFFF

DENSE_FIELD = "emb"
SPARSE_FIELD = "sparse_emb"

SPARSE_VOCAB = 32768
SPARSE_NNZ = 64

ALL_TYPES = ("flat_sparse", "hnsw_sparse", "ivf", "vamana")


def read_vecs_header(path: Path):
    with open(path, "rb") as f:
        hdr = f.read(HEADER_SIZE)
    if len(hdr) < HEADER_SIZE:
        raise ValueError(f"{path}: too small to contain a .vecs header")

    num_vecs = struct.unpack_from("<Q", hdr, 0)[0]
    version = struct.unpack_from("<H", hdr, 10)[0]
    meta_size = struct.unpack_from("<I", hdr, 12)[0]
    if version != 1:
        raise ValueError(f"{path}: unsupported .vecs version {version}")
    if num_vecs == 0:
        raise ValueError(f"{path}: empty .vecs file")

    (bitmap, _key_off, _key_size, dense_off, dense_size, sparse_off, sparse_size,
     _part_off, _part_size, _tag_off, _tag_size) = struct.unpack_from("<11Q", hdr, 16)

    if not bitmap & 1:
        raise ValueError(f"{path}: no dense section (bitmap={bitmap})")
    if sparse_off != UINT64_MAX and sparse_size > num_vecs * 12:
        raise ValueError(f"{path}: non-empty sparse vectors are not supported")

    element_bytes = dense_size // num_vecs
    if dense_size % num_vecs or element_bytes % 4:
        raise ValueError(
            f"{path}: dense section size {dense_size} inconsistent with {num_vecs} vectors"
        )

    data_base = HEADER_SIZE + meta_size
    return {
        "num_vecs": num_vecs,
        "dim": element_bytes // 4,
        "dense_offset": data_base + dense_off,
        "key_offset": data_base + _key_off,
    }


def make_sparse_vector(seed: int, nnz: int = SPARSE_NNZ, vocab: int = SPARSE_VOCAB):
    """Deterministic sparse vector {index: value} via pure integer hashing."""
    vec = {}
    k = 0
    while len(vec) < nnz:
        h = (seed * 0x9E3779B1 + k * 0x85EBCA6B + 0x27D4EB2F) & 0xFFFFFFFF
        h ^= h >> 15
        h = (h * 0x2C1B3C6D) & 0xFFFFFFFF
        h ^= h >> 12
        idx = h % vocab
        if idx not in vec:
            vec[idx] = ((h >> 16) & 0x7FFF) / 32767.0 * 0.9 + 0.1
        k += 1
    return dict(sorted(vec.items()))


def build_schema(index_type: str, dim: int, args) -> CollectionSchema:
    if index_type == "flat_sparse":
        vectors = [
            VectorSchema(
                DENSE_FIELD, DataType.VECTOR_FP32, dimension=dim,
                index_param=FlatIndexParam(metric_type=MetricType.COSINE),
            ),
            VectorSchema(
                SPARSE_FIELD, DataType.SPARSE_VECTOR_FP32,
                index_param=FlatIndexParam(metric_type=MetricType.IP),
            ),
        ]
    elif index_type == "hnsw_sparse":
        vectors = [
            VectorSchema(
                DENSE_FIELD, DataType.VECTOR_FP32, dimension=dim,
                index_param=HnswIndexParam(
                    metric_type=MetricType.COSINE, m=args.m,
                    ef_construction=args.ef_construction,
                    quantize_type=QuantizeType.INT8,
                ),
            ),
            VectorSchema(
                SPARSE_FIELD, DataType.SPARSE_VECTOR_FP32,
                index_param=HnswIndexParam(
                    metric_type=MetricType.IP, m=16, ef_construction=200,
                ),
            ),
        ]
    elif index_type == "ivf":
        vectors = [
            VectorSchema(
                DENSE_FIELD, DataType.VECTOR_FP32, dimension=dim,
                index_param=IVFIndexParam(
                    metric_type=MetricType.COSINE, n_list=args.ivf_nlist,
                    n_iters=10,
                ),
            ),
        ]
    elif index_type == "vamana":
        vectors = [
            VectorSchema(
                DENSE_FIELD, DataType.VECTOR_FP32, dimension=dim,
                index_param=VamanaIndexParam(
                    metric_type=MetricType.COSINE, max_degree=64,
                    search_list_size=100, alpha=1.2,
                ),
            ),
        ]
    else:
        raise SystemExit(f"unknown index type: {index_type}")
    return CollectionSchema(name=f"cohere_10k_{index_type}", vectors=vectors)


def build_one(index_type: str, vectors, keys, out_root: Path, args) -> Path:
    out_path = out_root / f"index_{index_type}_10k"
    if out_path.exists():
        raise SystemExit(f"output collection already exists: {out_path} — remove it first")

    num_vecs = vectors.shape[0]
    dim = vectors.shape[1]
    schema = build_schema(index_type, dim, args)
    print(f"[{index_type}] building {num_vecs} docs -> {out_path}", flush=True)

    zvec.init()
    coll = zvec.create_and_open(
        str(out_path), schema, CollectionOption(read_only=False, enable_mmap=True)
    )
    try:
        t0 = time.perf_counter()
        inserted = 0
        for start in range(0, num_vecs, args.batch_size):
            stop = min(start + args.batch_size, num_vecs)
            docs = []
            for i in range(start, stop):
                vecs = {DENSE_FIELD: vectors[i].tolist()}
                if index_type in ("flat_sparse", "hnsw_sparse"):
                    vecs[SPARSE_FIELD] = make_sparse_vector(int(keys[i]))
                docs.append(Doc(id=str(int(keys[i])), vectors=vecs))
            statuses = coll.insert(docs)
            failed = [s for s in statuses if not s.ok()]
            if failed:
                raise RuntimeError(f"insert failed at batch [{start}, {stop}): {failed[:3]}")
            inserted += stop - start
            elapsed = time.perf_counter() - t0
            print(f"[{index_type}] inserted {inserted}/{num_vecs} ({elapsed:.1f}s)", flush=True)

        print(f"[{index_type}] optimizing (full index build) ...", flush=True)
        t_opt = time.perf_counter()
        coll.optimize(OptimizeOption(concurrency=args.threads))
        print(f"[{index_type}] optimize done in {time.perf_counter() - t_opt:.1f}s", flush=True)

        coll.flush()
        stats = coll.stats
        print(f"[{index_type}] doc_count={stats.doc_count} "
              f"index_completeness={stats.index_completeness}", flush=True)
        if stats.doc_count != num_vecs:
            raise RuntimeError(f"[{index_type}] doc_count {stats.doc_count} != {num_vecs}")
        completeness = stats.index_completeness
        values = completeness.values() if isinstance(completeness, dict) else [completeness]
        if any(v != 1.0 for v in values):
            raise RuntimeError(
                f"[{index_type}] index_completeness {completeness} != 1.0"
            )
    finally:
        coll.close()
    return out_path


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument(
        "--vecs",
        default=str(Path(__file__).resolve().parent / "cohere_train_vector_10k.zvec.vecs"),
    )
    parser.add_argument("--out-root", default=str(Path(__file__).resolve().parent))
    parser.add_argument("--types", default=",".join(ALL_TYPES),
                        help=f"comma list from {ALL_TYPES}")
    parser.add_argument("--limit", type=int, default=0,
                        help="build with only the first N docs (smoke test); 0 = all")
    parser.add_argument("--batch-size", type=int, default=1000)
    parser.add_argument("--threads", type=int, default=0)
    parser.add_argument("--m", type=int, default=50, help="dense HNSW M")
    parser.add_argument("--ef-construction", type=int, default=500, help="dense HNSW efC")
    parser.add_argument("--ivf-nlist", type=int, default=100, help="IVF n_list")
    args = parser.parse_args()
    if args.batch_size > 1024:
        raise SystemExit("--batch-size exceeds the max write batch size of 1024")

    types = [t.strip() for t in args.types.split(",") if t.strip()]
    for t in types:
        if t not in ALL_TYPES:
            raise SystemExit(f"unknown type {t!r}; choose from {ALL_TYPES}")

    vecs_path = Path(args.vecs)
    out_root = Path(args.out_root)
    out_root.mkdir(parents=True, exist_ok=True)

    info = read_vecs_header(vecs_path)
    num_vecs, dim = info["num_vecs"], info["dim"]
    if args.limit and args.limit < num_vecs:
        num_vecs = args.limit
    print(f"[build] source  : {vecs_path}")
    print(f"[build] vectors : {num_vecs} x {dim} (float32)")

    vectors = np.memmap(
        vecs_path, dtype=np.float32, mode="r",
        offset=info["dense_offset"], shape=(num_vecs, dim),
    )
    keys = np.memmap(
        vecs_path, dtype=np.uint64, mode="r",
        offset=info["key_offset"], shape=(num_vecs,),
    )

    for t in types:
        build_one(t, vectors, keys, out_root, args)

    print(f"[build] all collections written under: {out_root}")


if __name__ == "__main__":
    main()
