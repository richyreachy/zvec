"""Verify a cross-platform zvec test index and save/compare result baselines.

Re-opens a collection read-only, runs the 1000 Cohere test queries against the
dense field (recall vs ground truth), and runs deterministic sanity queries
against the sparse field (flat_sparse / hnsw_sparse indexes only).

Use --save-baseline on the machine that built the indexes (Windows) and
--compare-baseline on the other platforms (macOS / Linux) to detect any
cross-platform divergence in query results.

Usage:
    python verify_cross_platform.py --index index_hnsw_sparse_10k --type hnsw_sparse \
        --save-baseline baselines/hnsw_sparse.json
    python verify_cross_platform.py --index index_hnsw_sparse_10k --type hnsw_sparse \
        --compare-baseline baselines/hnsw_sparse.json
"""
from __future__ import annotations

import argparse
import json
import platform
import sys
import time
from pathlib import Path

import zvec
from zvec import (
    CollectionOption,
    HnswQueryParam,
    IVFQueryParam,
    Query,
    VamanaQueryParam,
)

from build_cross_platform_indexes import SPARSE_FIELD, DENSE_FIELD, make_sparse_vector

QUERY_SEED_BASE = 1_000_000_000
VALID_TYPES = ("flat_sparse", "hnsw_sparse", "ivf", "vamana")
SCORE_DECIMALS = 6


def load_queries(path: Path):
    queries = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            # format: "<id>;<f> <f> ... <f>;"
            parts = line.split(";")
            if len(parts) < 2:
                raise ValueError(f"{path}: malformed line: {line[:80]}")
            vec = [float(x) for x in parts[1].split()]
            queries.append((parts[0], vec))
    return queries


def load_ground_truth(path: Path):
    gt = {}
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            # format: "<query_id>;<id> <id> ... <id>"
            qid, _, rest = line.partition(";")
            gt[qid] = rest.split()
    return gt


def dense_param(args):
    if args.type == "hnsw_sparse":
        return HnswQueryParam(ef=args.ef)
    if args.type == "ivf":
        return IVFQueryParam(nprobe=args.nprobe)
    if args.type == "vamana":
        return VamanaQueryParam(ef_search=args.ef_search)
    return None  # flat_sparse: brute force, no params


def sparse_param(args):
    if args.type == "hnsw_sparse":
        return HnswQueryParam(ef=args.sparse_ef)
    return None  # flat_sparse: brute force, no params


def run(args) -> dict:
    ks = sorted({k for k in (int(x) for x in args.ks.split(",")) if 0 < k <= args.topk})
    queries = load_queries(Path(args.query_file))
    gt = load_ground_truth(Path(args.gt_file))
    param_desc = {"ef": args.ef, "nprobe": args.nprobe, "ef_search": args.ef_search,
                  "sparse_ef": args.sparse_ef}
    print(f"[verify] index     : {args.index}")
    print(f"[verify] type      : {args.type} (params: {param_desc})")
    print(f"[verify] queries   : {len(queries)} (topk={args.topk}, recall@{ks})")

    zvec.init()
    coll = zvec.open(args.index, CollectionOption(read_only=True, enable_mmap=True))
    try:
        stats = coll.stats
        print(f"[verify] doc_count : {stats.doc_count}")
        print(f"[verify] completeness : {stats.index_completeness}")

        d_param = dense_param(args)
        s_param = sparse_param(args)
        hits_at = {k: 0 for k in ks}
        dense_results = {}
        t0 = time.perf_counter()
        for n, (qid, vec) in enumerate(queries):
            truth = gt.get(qid)
            if not truth:
                raise ValueError(f"no ground truth for query id {qid}")
            hits = coll.query(
                Query(field_name=DENSE_FIELD, vector=vec, param=d_param),
                topk=args.topk,
            )
            retrieved = [h.id for h in hits]
            if len(retrieved) < args.topk:
                print(f"[verify] warn: query {qid} returned {len(retrieved)}/{args.topk}")
            for k in ks:
                hits_at[k] += len(set(retrieved[:k]) & set(truth[:k]))
            if n < args.baseline_queries:
                dense_results[qid] = [
                    [h.id, round(h.score, SCORE_DECIMALS)] for h in hits
                ]
        elapsed = time.perf_counter() - t0

        sparse_results = {}
        sparse_count = 0
        if args.type in ("flat_sparse", "hnsw_sparse"):
            t1 = time.perf_counter()
            for qid, _ in queries[: args.sparse_checks]:
                seed = QUERY_SEED_BASE + int(qid)
                svec = make_sparse_vector(seed)
                hits = coll.query(
                    Query(field_name=SPARSE_FIELD, vector=svec, param=s_param),
                    topk=args.sparse_topk,
                )
                sparse_results[str(seed)] = [
                    [h.id, round(h.score, SCORE_DECIMALS)] for h in hits
                ]
                sparse_count += 1
            sparse_elapsed = time.perf_counter() - t1
        else:
            sparse_elapsed = 0.0
    finally:
        coll.close()

    n = len(queries)
    recall_at = {str(k): hits_at[k] / (n * k) for k in ks}
    print("[verify] ---------------- results ----------------")
    for k in ks:
        print(f"[verify] recall@{k:<4}: {recall_at[str(k)]:.4f}")
    print(f"[verify] dense  : {elapsed:.2f}s for {n} queries ({n / elapsed:.1f} qps)")
    if sparse_count:
        print(f"[verify] sparse : {sparse_count} sanity queries in {sparse_elapsed:.2f}s")

    return {
        "meta": {
            "index_type": args.type,
            "topk": args.topk,
            "ks": ks,
            "query_params": param_desc,
            "doc_count": stats.doc_count,
            "dense_field": DENSE_FIELD,
            "sparse_field": SPARSE_FIELD,
            "num_queries": n,
            "num_dense_baseline_queries": len(dense_results),
            "sparse_checks": len(sparse_results),
            "sparse_topk": args.sparse_topk,
            "zvec_version": zvec.__version__,
            "platform": f"{platform.system()}/{platform.machine()}",
        },
        "recall_at": recall_at,
        "dense_results": dense_results,
        "sparse_results": sparse_results,
    }


def compare(baseline: dict, current: dict, args) -> int:
    failures = []

    b_meta, c_meta = baseline["meta"], current["meta"]
    for key in ("index_type", "topk", "ks", "doc_count", "num_queries",
                "num_dense_baseline_queries", "sparse_checks", "sparse_topk"):
        if b_meta[key] != c_meta[key]:
            failures.append(f"meta mismatch: {key}: {b_meta[key]!r} != {c_meta[key]!r}")

    for k, b_recall in baseline["recall_at"].items():
        c_recall = current["recall_at"].get(k)
        if c_recall is None or abs(b_recall - c_recall) > args.recall_tol:
            failures.append(f"recall@{k}: baseline {b_recall} vs current {c_recall}")

    # dense result comparison
    diff_queries = 0
    max_score_diff = 0.0
    for qid, b_res in baseline["dense_results"].items():
        c_res = current["dense_results"].get(qid)
        if c_res is None:
            failures.append(f"dense: query {qid} missing from current baseline slice")
            continue
        if [r[0] for r in b_res] != [r[0] for r in c_res]:
            diff_queries += 1
        for (b_id, b_score), (c_id, c_score) in zip(b_res, c_res):
            max_score_diff = max(max_score_diff, abs(b_score - c_score))

    # sparse result comparison
    sparse_diff = 0
    sparse_max_score_diff = 0.0
    for seed, b_res in baseline["sparse_results"].items():
        c_res = current["sparse_results"].get(seed)
        if c_res is None:
            failures.append(f"sparse: query seed {seed} missing from current results")
            continue
        if [r[0] for r in b_res] != [r[0] for r in c_res]:
            sparse_diff += 1
        for (b_id, b_score), (c_id, c_score) in zip(b_res, c_res):
            sparse_max_score_diff = max(sparse_max_score_diff, abs(b_score - c_score))

    n_dense = len(baseline["dense_results"])
    n_sparse = len(baseline["sparse_results"])
    print("[compare] ---------------- comparison ----------------")
    print(f"[compare] dense  : {n_dense - diff_queries}/{n_dense} recorded queries "
          f"have identical id sequences; max score diff {max_score_diff:.6f}")
    if n_sparse:
        print(f"[compare] sparse : {n_sparse - sparse_diff}/{n_sparse} sanity queries "
              f"have identical id sequences; max score diff {sparse_max_score_diff:.6f}")
    if diff_queries:
        failures.append(f"dense id sequences differ for {diff_queries}/{n_dense} queries")
    if sparse_diff:
        failures.append(f"sparse id sequences differ for {sparse_diff}/{n_sparse} queries")
    if max_score_diff > args.score_tol:
        failures.append(f"dense score diff {max_score_diff} exceeds tolerance {args.score_tol}")
    if sparse_max_score_diff > args.score_tol:
        failures.append(
            f"sparse score diff {sparse_max_score_diff} exceeds tolerance {args.score_tol}"
        )

    if failures:
        print("[compare] FAILED:")
        for f in failures:
            print(f"[compare]   - {f}")
        return 1
    print("[compare] OK: results match the baseline")
    return 0


def main() -> None:
    here = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--index", required=True, help="zvec collection directory")
    parser.add_argument("--type", required=True, choices=VALID_TYPES)
    parser.add_argument(
        "--query-file",
        default=str(here / "cohere_test_vector_1m.1000.new.txt"),
        help="test query file (<id>;<floats>;)",
    )
    parser.add_argument(
        "--gt-file", default=str(here / "neighbors_10k.txt"),
        help="ground truth file (<qid>;<id> <id> ...)",
    )
    parser.add_argument("--topk", type=int, default=100)
    parser.add_argument("--ks", default="1,10,100")
    parser.add_argument("--ef", type=int, default=500, help="HNSW ef (hnsw_sparse)")
    parser.add_argument("--nprobe", type=int, default=100, help="IVF nprobe")
    parser.add_argument("--ef-search", type=int, default=500, help="Vamana ef_search")
    parser.add_argument("--sparse-ef", type=int, default=200,
                        help="sparse HNSW ef (hnsw_sparse)")
    parser.add_argument("--sparse-checks", type=int, default=20,
                        help="number of sparse sanity queries")
    parser.add_argument("--sparse-topk", type=int, default=10)
    parser.add_argument("--baseline-queries", type=int, default=100,
                        help="record per-query dense results for the first N queries")
    parser.add_argument("--save-baseline", metavar="FILE",
                        help="write results baseline JSON to FILE")
    parser.add_argument("--compare-baseline", metavar="FILE",
                        help="compare results against baseline JSON FILE")
    parser.add_argument("--recall-tol", type=float, default=1e-9)
    parser.add_argument("--score-tol", type=float, default=1e-6)
    args = parser.parse_args()

    if args.save_baseline and args.compare_baseline:
        raise SystemExit("use either --save-baseline or --compare-baseline, not both")

    current = run(args)

    if args.save_baseline:
        out = Path(args.save_baseline)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(current, indent=1), encoding="utf-8")
        print(f"[verify] baseline saved: {out}")
    elif args.compare_baseline:
        baseline = json.loads(Path(args.compare_baseline).read_text(encoding="utf-8"))
        sys.exit(compare(baseline, current, args))


if __name__ == "__main__":
    main()
